# Candles
Data* + code examples used to create these graphs: https://twitter.com/kate_ptrv/status/1332398737604431874?s=20  <br/>
Plugin used to download reviews: https://chrome.google.com/webstore/detail/amazon-review-scraper/kpmpdlljfabhiffaoamleakiblkbmmle?hl=en

*Note that the dataset contains data on more candles than were used to create the original plots (IDs 1-3)
